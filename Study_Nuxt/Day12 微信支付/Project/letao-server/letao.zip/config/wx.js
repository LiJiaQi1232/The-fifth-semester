// appid
module.exports.appid = 'wx8397f8696b538317';
// 商户号
module.exports.mch_id = '1473426802';

// 微信下单
module.exports.orderUrl = 'https://api.mch.weixin.qq.com/pay/unifiedorder';

// 
module.exports.key = 'T6m9iK73b0kn9g5v426MKfHQH7X8rKwb'

// 微信下单成功后的回调地址
module.exports.notify_url = 'http://vips968.com:3001/pay/notify'