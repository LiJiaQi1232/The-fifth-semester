// 用户信息加密用加盐字符串
module.exports.secret='letao_secret'



// jwt 加密字符串
module.exports.jwtSecret='letao_secret'

// wx支付 