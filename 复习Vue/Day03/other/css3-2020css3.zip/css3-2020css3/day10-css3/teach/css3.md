# CSS3

### transform:转换

![image-20210316083241631](images/image-20210316083241631.png)

```html
    <ul>
        <li>正常的</li>
        <li>旋转的</li>
        <li>缩放的</li>
        <li>平移的</li>
        <li>综合的</li>
    </ul>
```

```css
* {
            padding: 0;
            margin: 0;
        }

        ul {
            list-style: none;
            width: 800px;
            height: 500px;
            margin: 100px auto;
            border: 1px solid #ccc;
        }

        ul li {
            width: 100px;
            height: 50px;
            margin-top: 50px;
            background-color: red;
        }

        ul li:nth-child(2) {
            /* 旋转45度 */
            transform: rotate(45deg);
        }

        ul li:nth-child(3) {
            /*  第一个参数:水平方向
                第二个参数:垂直方向
                注意点:
                如果取值是1, 代表不变
                如果取值大于1, 代表需要放大
                如果取值小于1, 代表需要缩小
                如果水平和垂直缩放都一样, 那么可以简写为一个参数 */
            transform: scale(1.4)
        }

        ul li:nth-child(4) {
            /* 平移 */
            transform: translate(200px)
        }

        ul li:nth-child(5) {
            /* 
                旋转 平移  缩放
                多个转换： 
                注意
                1.如果需要进行多个转换, 那么用空格隔开
                2.2D的转换模块会修改元素的坐标系, 所以旋转之后再平移就不是水平平移的
             */
            transform: rotate(45deg)  translate(100px)  scale(1.2);
        }
```

### transform-origin:形变中心点

![image-20210316084809818](images/image-20210316084809818.png).

```html
 <div class="box1">
        <div></div>
        <div></div>
        <div></div>
 </div>
```

```css
 * {
            padding: 0;
            margin: 0;
        }

        .box1 {
            width: 200px;
            height: 200px;
            margin: 100px auto;
            border: 1px solid #ccc;
            position: relative;
        }

        .box1 div {
            width: 200px;
            height: 200px;
            position: absolute;
            top: 0;
            left: 0;
        }

        .box1 div:nth-child(1) {
            background-color: red;
            transform: rotate(30deg);
            transform-origin: left top;
            /* transform-origin: center center; */
            /* transform-origin: 0% 0%; */
            /* transform-origin: 200px 0; */
            /* transform-origin: right top; */
            /* 通过transform-origin: 修改元素的形变中心点  
            
                默认是 center center

                参数1: 水平方向
                参数2: 垂直方向
                
                注意点
                    取值有三种形式
                    具体像素
                    百分比
                    特殊关键字

             */

            /* transform-origin: right bottom; */
        }

        .box1 div:nth-child(2) {
            background-color: green;
            transform: rotate(45deg);
            transform-origin: left top;
            /* transform-origin: center center; */
            /* transform-origin: 0% 0%; */
            /* transform-origin: 200px 0; */
            /* transform-origin: right bottom; */
        }

        .box1 div:nth-child(3) {
            background-color: blue;
            transform: rotate(60deg);
            transform-origin: left top;
            /* transform-origin: center center; */
            /* transform-origin: 0% 0%; */
            /* transform-origin: 200px 0; */
            /* transform-origin: right top; */
            /* transform-origin: right bottom; */
        }
```

### 旋转轴向

![image-20210316091455856](images/image-20210316091455856.png).

```html
  <div><img src="./imgs/rotateX.jpg"></div>
    <div><img src="./imgs/rotateY.jpg"></div>
    <div><img src="./imgs/rotateZ.jpg"></div>
```

```css
 div {
             width: 200px;
             height: 200px;
             margin: 50px auto;
             perspective: 500px;
         }
         div img {
             width: 100%;
             height: 100%;
         }


         div:nth-child(1) img {
             transform:rotateX(80deg)
         }

         div:nth-child(2) img {
             transform:rotateY(70deg)
         }

         div:nth-child(3) img {
             transform:rotateZ(100deg)
         }
```

### 水平垂直居中

![image-20210316094536854](images/image-20210316094536854.png).

```html
 <div class="father">
           <div class="son"></div>
      </div> 

```

```css
.father {
            width: 400px;
            height: 400px;
            margin:  200px auto;
            background-color: pink; 
            position: relative;
        }

        .son {
            /* 弊端：  需要知道盒子的宽高 才能决定 margin-left 和 margin-top 具体移动多少像素 */
            width: 80px;
            height: 80px;
            position: absolute;
            left: 50%;
            top: 50%;
            /* margin-left: -50px;
            margin-top: -50px; */
            transform:translate(-50%, -50%);
            background-color: red;
        }
```

### transform旋转案例

![image-20210316103557015](images/image-20210316103557015.png)

![image-20210316103614441](images/image-20210316103614441.png)

```html
<div class="box1">
   <img src="./imgs/pk.png" alt="">
</div>
```

```css
.box1 {
            width: 320px;
            height: 430px;
            background-color: pink;
            margin: 200px auto;
            border-radius: 20px;
            /* 透视:近大远小 */
            perspective: 500px;
        }

        .box1 img {
            width: 100%;
            height: 100%;
            transition: all 1s;
            transform-origin: bottom center;
            /* 沿着左边旋转 */
            /* transform-origin: left center; */
            /* transform-origin: right center; */
            /* transform-origin: top center; */
        }

        .box1:hover img {
            transform:rotateX(70deg)
            /* transform:rotateY(180deg) */
            /* transform:rotateX(180deg); */
        }
```

### 照片墙案例

![image-20210316110037271](images/image-20210316110037271.png)

```html
   <ul>
           <li><img src="./imgs/1.jpg" alt=""></li>
           <li><img src="./imgs/2.jpg" alt=""></li>
           <li><img src="./imgs/3.jpg" alt=""></li>
       </ul>
```

```css
* {
            padding: 0;
            margin: 0;
        }
        ul {
            list-style: none;
            height: 500px;
            background-color: skyblue;
            /* 只有子元素是行内 行内块 才可以当成文本一样居中 */
            text-align: center;
        }

        ul li {
            width: 200px;
            height: 300px;
            margin: 100px 30px;
            display: inline-block;
            border:5px solid #fff;
            box-shadow: 0 0 10px;
            position: relative; 
            transition: all 1s;
        }

        ul li img {
            width: 100%; 
            height: 100%;  
                    
        }

        ul li:nth-child(1) {
            transform: rotate(15deg);
        }
        ul li:nth-child(2) {
            transform: rotate(-30deg);
        }
        ul li:nth-child(3) {
            transform: rotate(45deg);
        }

       ul li:hover {
           z-index: 10;
           transform: scale(1.5);
       } 
```

### 动画

![image-20210316112335153](images/image-20210316112335153.png).

```html
  <div></div>
```

```css
 div {
            width: 200px;
            height: 200px;
            background-color: pink;
            /* transition: all 1s; */
            /* 告诉系统动画名称是sport */
            animation-name: sport;
            /* 告诉动画持续的时间是2s */
            animation-duration: 2s;
        }

        @keyframes sport {
            from {
                margin-left: 0;
            }

            to {
                margin-left: 500px;
            }
        }
```

### 动画常用属性

![image-20210316114650511](images/image-20210316114650511.png)

```html
 <div></div>
```

```css
 div {
            width: 200px;
            height: 200px;
            background-color: pink;
            /* 动画名称 */
            animation-name: move;
            /* 动画持续时间 */
            animation-duration: 2s;
            /* 动画延迟的时间 */
            /* animation-delay: 1s; */
            /* 动画执行的速度 */
            animation-timing-function: linear;
            /* 3. animation-iteration-count   告诉系统动画需要执行几次 */
            /* animation-iteration-count: 3; */
            animation-iteration-count: 4;
            /*告诉系统是否需要执行往返动画
            normal, 默认的取值, 执行完一次之后回到起点继续执行下一次
            alternate, 往返动画, 执行完一次之后往回执行下一次   
              */
            animation-direction:alternate;
        }

        div:hover {
            /* 暂停
            告诉系统当前动画是否需要暂停
            取值:
            running: 执行动画
            paused: 暂停动画   
            
             */
            animation-play-state: paused;
        }


        @keyframes move {
            from {
                margin-left: 0;
            }
            to {
                margin-left: 500px;
            }
        }
```

### 百分比

![image-20210317082714720](images/image-20210317082714720.png)。

```htm
    <div></div>
```

```css
* {
            margin: 0;
            padding: 0;
        }

        div {
            width: 200px;
            height: 200px;
            background-color: pink;
            animation-name: move;
            animation-delay: 1s;
            animation-duration: 5s;
            animation-timing-function: linear;
            animation-iteration-count: infinite;
            position: absolute;
        }

        @keyframes move {
             0% {
                top: 0;
                left: 0;
             }
             25% {
                top: 0;
                left: 300px;
             }
             50% {
                top:300px;
                left: 300px;
             }

             75% {
                top: 300px;
                left: 0;
             }
             100% {
                top: 0;
                left: 0;
             }
        }
```

### animation-fill-mode

![image-20210317083946061](images/image-20210317083946061.png).

```html
  <div class="box"></div>
```

```css
 .box {
            width: 200px;
            height: 200px;
            margin: 100px auto;
            background-color: pink;
            animation-name: change;
            animation-delay: 2s;
            animation-duration: 2s;
            /* 指定动画等待状态和结束状态的样式

             动画三种状态:
             1.等待状态  backwards: 让元素等待状态的时候显示动画第一帧的样式
             2.执行状态
             3.结束状态  forwards: 让元素结束状态保持动画最后一帧的样式

       取值:
            none: 不做任何改变
            forwards: 让元素结束状态保持动画最后一帧的样式
            backwards: 让元素等待状态的时候显示动画第一帧的样式
            both: 让元素等待状态显示动画第一帧的样式, 让元素结束状态保持动画最后一帧的样式 */
            /* animation-fill-mode: forwards; */
            /* animation-fill-mode: backwards; */
            animation-fill-mode: both;
        }

        @keyframes  change {
            0% {
                transform: rotate(15deg);
            }

            50% {
                transform: rotate(35deg);
            }

            75% {
                transform: rotate(60deg);
            }
            100% {
                transform: rotate(80deg);
            }
        }
```

### 动画简写

```css
animation:动画名称 动画时长 动画运动速度 延迟时间 执行次数 往返动画;
animation:动画名称 动画时长;  动画模块连写格式的简写
```

### 正方体

![image-20210317095116869](images/image-20210317095116869.png).

```html
<ul>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
</ul>
```

```css
 * {
            padding: 0;
            margin: 0;
        }

        ul {
            list-style: none;
            width: 200px;
            height: 200px;
            border: 1px solid #ccc;
            margin: 100px auto;
            position: relative;
            transform-style: preserve-3d;
            /* transform: rotateX(0deg)  rotateY(0deg); */
            animation: sport 5s linear 0s infinite normal;
        }

        @keyframes sport {
            from {
                /* transform: rotateY(0deg); */
                /* transform: rotateX(0deg); */
                transform: rotateX(0deg) rotateY(0deg);
            }

            to {
                /* transform: rotateY(360deg); */
                /* transform: rotateX(360deg); */
                transform: rotateX(80deg) rotateY(360deg);
            }
        }

        ul li {
            width: 200px;
            height: 200px;
            position: absolute;
            top: 0;
            left: 0;
        }
        /* 左面 */
        ul li:nth-child(1) {
            background-color: red;
            transform: translateX(-100px) rotateY(90deg);
            background: url(./imgs/1.jpg);
            background-size: 200px 200px;
        }
        /* 右面 */
        ul li:nth-child(2) {
            background-color: green;
            transform: translateX(100px) rotateY(90deg);
            background: url(./imgs/2.jpg);
            background-size: 200px 200px;
        }
        /* 上面 */
        ul li:nth-child(3) {
            background-color: blue;
            transform: translateY(-100px) rotateX(90deg);
            background: url(./imgs/3.jpg);
            background-size: 200px 200px;
        }
        /* 下面 */
        ul li:nth-child(4) {
            background-color: pink;
            transform: translateY(100px) rotateX(90deg);
            background: url(./imgs/1.jpg);
            background-size: 200px 200px;

        }
        /* 后面 */
        ul li:nth-child(5) {
            background-color: aqua;
            transform: translateZ(-100px);
            background: url(./imgs/3.jpg);
            background-size: 200px 200px;
        }
        /* 前面 */
        ul li:nth-child(6) {
            background-color: purple;
            transform: translateZ(100px);
            background: url(./imgs/2.jpg);
            background-size: 200px 200px;
        }

```

### 多背景

![image-20210317101734943](images/image-20210317101734943.png).

```html
    <div></div>
```

```css

        div {
            width: 600px;
            height: 400px;
            margin: 100px auto;
            border: 1px solid #ccc;
            background:url(./imgs/1.jpg), url(./imgs/2.jpg),url(./imgs/3.jpg), url(./imgs/1.jpg);
            /* background-size: 200px 200px, 100px 100px, 50px 50px, 80px 80px; */
            background-size: 200px 200px;
            background-repeat: no-repeat;
            background-position: left top, right top, left bottom, right bottom;
        }
```

### 卡拉ok

![image-20210317104102801](images/image-20210317104102801.png)

```html
 <div class="box">穿越时空, 竭尽全力</div>
```

```css
* {
            padding: 0;
            margin: 0;
        }

        div {
            width: 750px;
            height: 78px;
            line-height: 78px;
            font-size: 65px;
            font-weight: bold;
            margin: 100px auto;
            border: 1px solid #ccc;
            color: transparent;
             /* -moz-对应 Firefox,
            -webkit-对应 Safari and Chrome
            -o- for Opera
            -ms- for Internet Explorer */
            /* 文字颜色和背景颜色一致 */
           
            background: url(./imgs/text_bg.jpg);
            background-repeat: no-repeat;
            background-position:-800px 0;
            background-color: red;
            -webkit-background-clip: text;
            animation: move 5s linear 0s infinite;
        }


        @keyframes move {
            form {
                background-position: -800px 0;
            }
            to {
                background-position: 0 0;
            }
        }
```

### 圣杯布局

![image-20210317111500002](images/image-20210317111500002.png).

```html
 <!--圣杯布局 
        1. 先搞一个盒子，里面放三个子盒子 
        2. 固定左边和右边盒子的宽度
        3. 设置中间的盒子是父亲的宽度的100%
        4. 让三个盒子在一行中显示
        5. 设置大盒子左右的padding=200px
        6. 让左侧的盒子设置margin-left=-100%
        7. 通过相对定位让左侧盒子放到最左边left=-200px
        8. 设置右侧盒子margin-reft=-200px
        9. 通过相对定位设置右侧盒子的left=200px
        10.通过min-width设置大盒子最小宽度
    -->
 <div class="box">
         <div class="center">
             Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis illum error deleniti hic adipisci repellendus ullam. Asperiores obcaecati doloribus quidem excepturi voluptate commodi, quae, beatae temporibus iusto cupiditate odio labore?
         </div>
         <div class="left"></div>
         <div class="right"></div>
    </div>
```

```css
 * {
            padding: 0;
            margin: 0;
         }

         .left,.right {
             width: 200px;
             height: 200px;
             background-color: red;
             float: left;
             margin-left: -100%;
         } 

         .left {
            position: relative;
            left: -200px;
         }

         .right {
             margin-left: -200px;
             position: relative;
             left: 200px;
         }

         .center {
             width: 100%;
             height: 200px;
             background-color: pink;
             float: left;
         }

         .box {
             background-color: skyblue;
             padding: 0 200px;
             overflow: hidden;
             min-width: 400px;
         }

```

### 双飞翼布局

![image-20210317113308502](images/image-20210317113308502.png)

```html
  <!-- 

        双飞翼布局：
        1. 先搞一个盒子，里面放三个子盒子 
        2. 固定左边和右边盒子的宽度
        3. 设置中间的盒子是父亲的宽度的100%
        4. 让三个盒子在一行中显示
        5. 给中间的盒子新增一个div
        6. 设置中间小盒子center-in margin:0 200px
        7. 设置左边的盒子margin-left=-100%
        8. 设置右边的盒子margin-left=-200px;
     -->

     <div class="box">
         <div class="center">
             <div class="center-in">
                 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的 中间的
             </div>
         </div>
         <div class="left"></div>
         <div class="right"></div>
     </div>
```

```css
* {
            padding: 0;
            margin: 0;
        }

        .left,.right {
            width: 200px;
            height: 200px;
            background-color: red;
            float: left;
        }

        .left {
            margin-left: -100%;
        }

        .right {
            margin-left: -200px;
        }
        .center {
            width: 100%;
            height: 200px;
            background-color: pink;
            float: left;
        }

        .center-in {
            height: 200px;
            background-color: purple;
            margin: 0 200px;
        }

        .box {
            background-color: skyblue;
            overflow: hidden;
        }
```

