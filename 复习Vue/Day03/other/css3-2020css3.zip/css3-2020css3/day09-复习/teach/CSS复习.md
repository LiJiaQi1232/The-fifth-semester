# CSS复习

### 1.盒子模型

![image-20210308083225461](C:%5CUsers%5CAdministrator%5CAppData%5CRoaming%5CTypora%5Ctypora-user-images%5Cimage-20210308083225461.png).

```javascript
1.内容的宽度和高度

    就是通过width/height属性设置的宽度和高度
    
2.元素的宽度和高度
    
    宽度 = 左边框 + 左内边距 + width + 右内边距 + 右边框
    高度 同理可证
    
3.元素空间的宽度和高度
    
    宽度 = 左外边距 + 左边框 + 左内边距 + width + 右内边距 + 右边框 + 右外边距
    高度 同理可证
```

### box-sizing:

![image-20210308084032942](images/image-20210308084032942.png).

```javascript
1.CSS3中新增了一个box-sizing属性, 这个属性可以保证我们给盒子新增padding和border之后, 盒子元素的宽度和高度不变

2.box-sizing原理

 增加padding和border之后要想保证盒子元素的宽高不变, 那么就必须减去一部分内容的宽度和高度

3.box-sizing取值

   content-box
            元素的宽高 = 边框 + 内边距 + 内容宽高
    border-box
            元素的宽高 = width/height的宽高
```

### 水平居中

![image-20210308084601627](images/image-20210308084601627.png)

#### html结构

.![image-20210308084637750](images/image-20210308084637750.png).

#### css代码

![image-20210308084750803](images/image-20210308084750803.png).

```javascript
1.1.text-align:center;和margin:0 auto;区别

text-align: center;作用
设置盒子中存储的文字/图片水平居中

margin:0 auto;作用
让盒子自己水平居中
```



### 浮动

![image-20210308085935251](images/image-20210308085935251.png).

```css
 .box1 {
     width: 200px;
     height: 200px;
     background-color: pink;
     float: left;
     margin: 0 auto;
  }



​    .box2 {

​      width: 200px;

​      height: 200px;

​      background-color: red;

​      float: left;

​    }
```

```html
<span class="box1">我是span</span>
<div class="box2"></div>
```

```javascript
1.什么是网页的布局方式?
网页的布局方式其实就是指浏览器是如何对网页中的元素进行排版的

1.标准流(文档流/普通流)排版方式
1.1其实浏览器默认的排版方式就是标准流的排版方式
1.2在CSS中将元素分为三类, 分别是块级元素/行内元素/行内块级元素
1.3 在标准流中有两种排版方式, 一种是垂直排版, 一种是水平排版
垂直排版, 如果元素是块级元素, 那么就会垂直排版
水平排版, 如果元素是行内元素/行内块级元素, 那么就会水平排版

2.浮动流排版方式
2.1浮动流是一种"脱离标准流"的排版方式
2.2浮动流只有一种排版方式, 就是水平排版. 它只能设置某个元素左对齐或者右对齐

注意点:
1.浮动流中没有居中对齐, 也就是没有center这个取值
2.在浮动流中是不可以使用margin: 0 auto;

特点:
1.在浮动流中是不区分块级元素/行内元素/行内块级元素的
无论是级元素/行内元素/行内块级元素都可以水平排版
2.在浮动流中无论是块级元素/行内元素/行内块级元素都可以设置宽高
3.综上所述, 浮动流中的元素和标准流中的行内块级元素很像
```

### 浮动元素的排序规则

![image-20210308091930409](images/image-20210308091930409.png).

```html
  <div class="box1">1</div>
  <div class="box2">2</div>
  <div class="box3">3</div>
  <div class="box4">4</div>
```

```css
 .box1 {
            width: 100px;
            height: 100px;
            background-color: pink;
            float: left;
        }

        .box2 {
            width: 200px;
            height: 200px;
            background-color: red;
            float: left;
        }
        .box3 {
            width: 200px;
            height: 200px;
            background-color: blue;
            float: right;
        }
        .box4 {
            width: 200px;
            height: 200px;
            background-color: green;
            float: right;
        }
```

```javascript
 1.浮动元素排序规则?

1.1相同方向上的浮动元素, 先浮动的元素会显示在前面, 后浮动的元素会显示在后面
1.2不同方向上的浮动元素, 左浮动会向左浮动, 右浮动会向右浮动
1.3浮动元素浮动之后的位置, 由浮动元素浮动之前在标准流中的位置来确定
```

### 浮动元素的贴靠现象

![image-20210308093241835](images/image-20210308093241835.png).

```html
 <!-- 1.什么是浮动元素贴靠现象?

    1.如果父元素的宽度能够显示所有浮动元素, 那么浮动的元素会并排显示
    2.如果父元素的宽度不能显示所有浮动元素, 那么会从最后一个元开始往前贴靠
    3.如果贴靠了前面所有浮动元素之后都不能显示, 最终会贴靠到父元素的左边或者右边 -->
    <div class="father">
        <div class="son1">son1</div>
        <div class="son2">son2</div>
        <div class="son3">son3</div>
    </div>
```

```css
  .father {
            width: 600px;
            height: 600px;
            background-color: pink;
        }
        .son1 {
            width: 100px;
            height: 400px;
            background-color: yellow;
            float: left;
        }
        .son2 {
            width: 200px;
            height: 200px;
            padding: 20px;
            background-color: blue;
            float: left;
        }
        .son3 {
            width: 300px;
            height: 300px;
            background-color: green;
            float: left;
        }
```

### 浮动自围现象

```javascript
1.什么是浮动元素字围现象?

浮动元素不会挡住没有浮动元素中的文字, 没有浮动的文字会自动给浮动的元素让位置,这个就是浮动元素字围现象
```



![image-20210308093803944](images/image-20210308093803944.png)

```html
<img src="./imgs/赵敏.jpg" alt="">
    <p>赵敏 （金庸小说《倚天屠龙记》中的角色） 编辑 讨论45 上传视频
        赵敏，本名敏敏特穆尔，金庸武侠小说《倚天屠龙记》中的角色，汝阳王察罕特穆尔之女，封号绍敏郡主 [1]  。
        她生为女儿身，曾期许自己能创一番大事业，奉命剿灭反贼，下毒囚禁六大门派于万安寺，自从绿柳山庄事件后，对敌军首领张无忌一往情深。她敢爱敢恨、追求爱情勇往直前，并不像传统女子的忸怩作态，于荒岛之上被周芷若嫁祸（杀张无忌表妹殷离，偷取屠龙刀、倚天剑），濠州婚礼上以谢逊毛发带走张无忌，此后放弃荣华富贵和郡主的身份，为爱追随张无忌。最后，张无忌辞退明教教主之位，与赵敏退隐江湖。新修版改为张无忌随赵敏去蒙古。
        赵敏时而明艳不可方物，艳丽非凡，时而端严之至，令人不敢逼视。她生性机智多谋，心思敏捷，精灵俊秀，直率豪爽，具有雄才大略，是金庸笔下最受读者喜爱的人物之一 [2]  。
        人物关系
        纠错
        
        父亲 察罕特穆尔
         
        中文名赵敏别    名明明特穆尔、赵明（连载版小说姓名）、敏敏特穆尔饰    演陈好逑（1965年香港粤语电影）
        汪明荃（1978年香港无线电视剧）
        井莉（1978年香港邵氏电影）
        刘玉璞（1984年台湾台视电视剧）
        黎美娴（1986年香港无线电视剧）展开
        
        配    音井莉（1978年香港邵氏电影）、吴萍（1986年香港无线电视剧）、林芳雪；卢素娟（1994年台湾台视电视剧）、苏柏丽（2001年香港无线电视剧）、冯骏骅（2003年合拍电视剧）、季冠霖（2009年内地电视剧）、徐佳琦（2019年内地电视剧）性    别女登场作品倚天屠龙记年    龄约16~17岁（出场年龄）朝    代元末明初民    族蒙古族登场回目第二十三回登场地点玉门关甘凉大路柳树下经典场面绿柳山庄、濠州抢婚、天地同寿身    份汝阳王之女封    号绍敏郡主喜    好生性好武，作汉人打扮，说汉话曾用兵器倚天剑、圣火令、长剑、金钗、金针代表之花玫瑰
        目录
        1 人物关系
        2 人物称呼
        3 形象设计
        4 形象气质
        5 性格特征
        6 动人之处
        7 外貌描写
        ▪ 衣饰
        ▪ 性感
        ▪ 文采
        ▪ 书法
        ▪ 园艺
        ▪ 才能
        ▪ 志向
        ▪ 名言
        8 人物武功
        9 人物经历
        ▪ 芳心暗许
        ▪ 转变关键
        ▪ 识破计谋
        10 原型出处
        11 人物评析
        12 影视形象
        人物关系编辑
        父亲：汝阳王察罕特穆尔（官居太尉，执掌天下兵马大权）
        母亲：汝阳王妃
        兄长：库库·特穆尔（汉名：王保保）
        部属：苦头陀（明教光明右使范遥）、玄冥二老（鹿杖客、鹤笔翁）、摩诃巴思、温卧儿、方东白（阿大）、成昆、阿二、阿三、乌旺阿普、神箭八雄、蒙古兵等。</p>
```

### 浮动元素高度问题

![image-20210308094457002](images/image-20210308094457002.png).

```html
    <!-- 1.浮动元素高度问题?

    1.在标准流中内容的高度可以撑起父元素的高度
    2.在浮动流中浮动的元素是不可以撑起父元素的高度的 -->
    <div class="father">
        <div class="son"></div>
    </div>
```

```css
  .father {
                width: 300px;
                border: 2px solid #ccc;
                /* background-color: pink;
                 */
            }
            .son {
                width: 200px;
                height: 200px;
                background-color: red;
                float: left;
            }
```

![image-20210308102619485](images/image-20210308102619485.png)

```html
 <div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>

    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
    .box1 {
                background-color: pink;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

```

![image-20210308102731036](images/image-20210308102731036.png)

```css
 .box1 {
                background-color: pink;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }
```

### 清除浮动方式1

![image-20210308103659453](images/image-20210308103659453.png)

```html
<!-- 1.清除浮动的第一种方式

给前面一个父元素设置高度

注意点:
在企业开发中, 我们能不写高度就不写高度, 所以这种方式用得很
 -->
 <div class="box1">
    <p>我是文本</p>
    <p>我是文本</p>
    <p>我是文本</p>
</div>

<div class="box2">
    <p>我是文本</p>
    <p>我是文本</p>
    <p>我是文本</p>
</div>
```

```css
   * {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                height: 21px;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }
```

### 清除浮动方式2

![image-20210308104443949](images/image-20210308104443949.png).

```html
<div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
    
    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
 * {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
                clear: both;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }
```

### clear清除浮动导致margin失效

![image-20210308105102343](images/image-20210308105102343.png).

```html
注意点:
当我们给某个元素添加clear属性之后, 那么这个属性的margin属性就会失效 
<div class="box1"></div>
    <div class="box2"></div>
```

```css
 .box1 {
                width: 200px;
                height: 200px;
                background-color: red;
                float: left;
            }

            .box2 {
                width: 200px;
                height: 200px;
                background-color: pink;
                clear: both;
                margin-top: 10px;
            }
```

外墙/内墙

外墙法

![image-20210308114410207](images/image-20210308114410207.png)

```html
  <div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
        
    </div>
    <div class="wall"></div>
    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
   body {
            border:  1px solid #ccc;
        }
        * {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                margin-bottom: 30px;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
                margin-top: 20px;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }

            .wall {
                clear: both;
            }
```



内墙法

![image-20210308114157490](images/image-20210308114157490.png)

```html
  <div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
        <div class="wall"></div>
    </div>
  
    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
 body {
            border:  1px solid #ccc;
        }
        * {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                margin-bottom: 30px;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
                margin-top: 20px;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }

            .wall {
                clear: both;
            }
```

### 伪元素清除浮动

![image-20210308115017526](images/image-20210308115017526.png)

```html
    <div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
        <!-- <div class="wall"></div> -->
    </div>
    
    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
  * {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                margin-bottom: 30px;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
                margin-top: 20px;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }

           .box1::after {
               /* 设置一个空内容 */
               content: '';
               /* 转成块元素 */
               display: block;
               /* 不要高度 */
               height: 0;
               /* 隐藏元素 */
               visibility: hidden;
               /* 清除左右浮动 */
               clear: both;
           }

          .box1 {
               /* 兼容IE6 */
               *zoom:1;
           }
```

### overflow清除浮动

![image-20210308115546831](images/image-20210308115546831.png)

```html
 <div class="box1">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
        <!-- <div class="wall"></div> -->
    </div>
    
    <div class="box2">
        <p>我是文本</p>
        <p>我是文本</p>
        <p>我是文本</p>
    </div>
```

```css
* {
               padding: 0;
               margin: 0;
           }
            .box1 {
                background-color: pink;
                margin-bottom: 30px;
            }

            .box1 p {
                width: 200px;
                background-color: yellow;
            }

            .box2 {
                background-color: blue;
                margin-top: 20px;
            }
            .box2 p {
               width: 200px;
               background-color: green;
            }

            p {
                float: left;
            }

            .box1 {
                overflow: hidden;
                /* IE6兼容 */
                *zoom:1;
            }
```

### 相对定位

![image-20210309082342812](images/image-20210309082342812.png).

```html
  <!-- 1.什么是相对定位？

    相对定位就是相对于自己以前在标准流中的位置来移动
    
    3.相对定位注意点
    3.1相对定位是不脱离标准流的, 会继续在标准流中占用一份空间
    3.2在相对定位中同一个方向上的定位属性只能使用一个
    3.3由于相对定位是不脱离标准流的, 所以在相对定位中是区分块级元素/行内元素/行内块级元素
    3.4由于相对定位是不脱离标准流的, 并且相对定位的元素会占用标准流中的位置, 所以当给相对定位的元素设置margin/padding等属性的时
    会影响到标准流的布局
    
    4.相对定位应用场景
    4.1用于对元素进行微调
    4.2配合绝对定位来使用 -->


    <div class="box1"></div>
    <div class="box2"></div>
    <div class="box3"></div>

    <span>我是span</span>
```

```css
 div {
            width: 200px;
            height: 200px;
        }
        .box1 {
            background-color: red;
        }
        .box2 {
            background-color: green;
            position: relative;
            top:10px;
            /* bottom: 10px; */
            left: 10px;
            padding: 20px;
            /* right: 10px; */
        }
        .box3 {
            background-color: blue;
        }

        span {
            position: relative;
            width: 200px;
            height: 200px;
            background-color: pink;
        }
```

绝对定位

![image-20210309083029300](images/image-20210309083029300.png).

```html
<!-- 1.什么是绝对定位？

    绝对定位就是相对于body来定位
    
    2.绝对定位注意点
    2.1绝对定位的元素是脱离标准流的
    2.2绝对定位的元素是不区分块级元素/行内元素/行内块级元素 -->
    <div class="box1"></div>
    <span>我是span</span>
```

```css
  .box1 {
            width: 200px;
            height: 200px;
            background-color: pink;
            position: absolute;
            bottom: 0;
            left: 0;
        }

        span {
            position: absolute;
            width: 200px;
            height: 200px;
            background-color: red;
        }
```

### 决定定位参照点

![image-20210309084020277](images/image-20210309084020277.png).

```ht
  <div class="father">
    <div class="son"></div>
</div>
```

```css
 .father {
            width: 400px;
            height: 400px;
            margin: 100px auto;
            background-color: pink;
            position: relative;
        }
        .son {
            width: 200px;
            height: 200px;
            background-color:red;
            position: absolute;
            /* top: 0;
            left: 0; */
            right: 0;
            bottom: 0;
        }
```

![image-20210309084131265](images/image-20210309084131265.png)

```html
<!-- 1.绝对定位-参考点？

1.规律
1.默认情况下所有的绝对定位的元素, 无论有没有祖先元素, 都会以body作为参考点

2.如果一个绝对定位的元素有祖先元素, 并且祖先元素也是定位流, 那么这个绝对定位的元素就会以定位流的那个祖先元素作为参考点
2.1只要是这个绝对定位元素的祖先元素都可以
2.2指的定位流是指绝对定位/相对定位/固定定位
2.3定位流中只有静态定位不行

3.如果一个绝对定位的元素有祖先元素, 并且祖先元素也是定位流, 而且祖先元素中有多个元素都是定位流, 那么这个绝对定位的元素会以离它最近的那个定位流的祖先元素为参考点 -->
<div class="grand">
    <div class="father">
        <div class="son"></div>
    </div>
  
  </div>
```

```css
 .grand {
            width: 800px;
            height: 800px;
            background-color: yellow;
            position: relative;
        }
        .father {
            width: 400px;
            height: 400px;
            margin: 100px auto;
            background-color: pink;
            position: relative;
        }
        .son {
            width: 200px;
            height: 200px;
            background-color:red;
            position: absolute;
            /* top: 0;
            left: 0; */
            right: 0;
            bottom: 0;
        }
```

### 绝对定位注意点

![image-20210309085334876](images/image-20210309085334876.png).



![image-20210309085409595](images/image-20210309085409595.png).



```html
<--绝对定位-注意点？
    1.如果一个绝对定位的元素是以body作为参考点, 那么其实是以网页首屏的宽度和高度作为参考点,
     而不是以整个网页的宽度和高度作为参考点 -->
<div class="box1"></div>
    <div class="box2"></div>
    <div class="box3"></div>
```

```css
 .box1 {
            width: 2000px;
            height: 50px;
            background-color: blue;
        }
        .box2 {
            width: 200px;
            height: 200px;
            background-color: red;
            position: absolute;
            right: 0;
            bottom: 0;
        }
        .box3 {
            width: 200px;
            height: 2000px;
            background-color: yellow;
        }
```



![image-20210309085204569](images/image-20210309085204569.png).

```html
 <!-- 绝对定位-注意点？
    2.一个绝对定位的元素会忽略祖先元素的padding -->
    <!-- <div class="box1"></div>
    <div class="box2"></div>
    <div class="box3"></div> -->

    <div class="father">
        <div class="son"></div>
    </div>
```

```css
 .father {
            width: 400px;
            height: 400px;
            background-color: red;
            padding: 20px;
            position: relative;
        }
        .son {
            width: 100px;
            height: 100px;
            background-color: pink;
            position: absolute;
            top: 0;
            left: 0;
        }
```

### 子绝父相

![image-20210309090949807](images/image-20210309090949807.png).

```html
    <!-- 绝对定位-子绝父相？

相对定位弊端:
            相对定位不会脱离标准流, 会继续在标准流中占用一份空间, 所以不利于布局界面

绝对定位弊端:
            默认情况下绝对定位的元素会以body作为参考点, 所以会随着浏览器的宽度高度的变化而变化

子绝父相
            子元素用绝对定位, 父元素用相对定位 -->

            <div class="father">
                <div class="son"></div>
            </div>

```

```css
.father {
            width: 400px;
            height: 400px;
            background-color: pink;
            position: relative;
            left: 50%;
            top:200px;
            margin-left: -200px;
            
        }
        .son {
            width: 100px;
            height: 100px;
            background-color: blue;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -50px;
            margin-top: -50px;
        }
```

### 固定定位

![image-20210309092144931](images/image-20210309092144931.png).

```html

  <!-- 什么是固定定位?

    固定定位和前面学习的背景关联方式很像, 背景定位可以让背景图片不随着滚动条的滚动而滚动, 
    而固定定位可以让某个盒子不随着滚动条的滚动而滚动
    
    注意点:
    1.固定定位的元素是脱离标准流的, 不会占用标准流中的空间
    2.固定定位和绝对定位一样不区分行内/块级/行内块级
    3.IE6不支持固定定位 -->

    <div class="box1">1</div>
    <div class="box2">2</div>
    <div class="box3">3</div>

    <!-- <span>我是span</span> -->
```

```css
div {
            width: 200px;
            height: 200px;
        }
        .box1 {
            background-color:red;
            /* height: 2000px; */
        }
        .box2 {
            background-color:green;
            position: fixed;
            left: 50px;
            top: 50px;
        }
        .box3 {
            background-color:pink;
        }
```

### z-index从父现象

![image-20210309093801815](images/image-20210309093801815.png).

```html
   <!-- 定位流-z-index属性

1.什么是z-index属性?
   1.1  默认情况下所有的元素都有一个默认的z-index属性, 取值是auto.
   1.2  z-index属性的作用是专门用于控制定位流元素的覆盖关系的

1. 默认情况下定位流的元素会盖住标准流的元素
2. 默认情况下定位流的元素后面编写的会盖住前面编写的
3. 如果定位流的元素设置了z-index属性, 那么谁的z-index属性比较大, 谁就会显示在上面

注意点:
1.从父现象
1.1如果两个元素的父元素都没有设置z-index属性, 那么谁的z-index属性比较大谁就显示在上面
1.2如果两个元素的父元素设置了z-index属性, 那么子元素的z-index属性就会失效, 
也就是说谁的父元素的z-index属性比较大谁就会显示在上面 -->


 <div class="box1">
     <p>我是段落1</p>
 </div>

 <div class="box2">
    <p>我是段落2</p>
</div>
```

```css
 .box1 {
            width: 200px;
            height: 200px;
            background-color: pink;
            position: relative;
            z-index: 2;
        }

        .box1 p {
            width: 100px;
            height: 100px;
            background-color: red;
            position: absolute;
            top: 180px;
            left: 220px;
            /* z-index: 10; */
        }

        .box2 {
            width: 200px;
            height: 200px;
            background-color: blue;
            position: relative;
            z-index: 3;
        }
        .box2 p {
            width: 100px;
            height: 100px;
            background-color: yellow;
            position: absolute;
            left: 230px;
            top: 40px;
        }
```

### 过渡模块

![image-20210309103323194](images/image-20210309103323194.png).

```html
   <div class="box1"></div>
```

```css

 * {
            padding: 0;
            margin: 0;
        }
        .box1 {
            width: 200px;
            height: 200px;
            background-color: pink;
            /* transition-property：告诉系统哪个属性需要执行过渡效果
                transition-duration：告诉  系统过渡效果持续的时长
                transition-delay：告诉系统延迟多少秒之后才开始过渡动画
                transition-timing-function：告诉系统过渡动画的运动的速度 */
            /* transition-property：告诉系统哪个属性需要执行过渡效果 */
            transition-property: width,background-color;
            /*  transition-duration：告诉  系统过渡效果持续的时长 */
            transition-duration: 5s;
            /* transition-delay：告诉系统延迟多少秒之后才开始过渡动画 */
            transition-delay: 2s;



            /* transition-timing-function: linear; */
        }
        .box1:hover {
            width: 400px;
            background-color: blue;
        }

```

![image-20210309103447287](images/image-20210309103447287.png)

```html
   <ul>
       <li>我是匀速</li>
       <li>ease</li>
       <li>ease-in</li>
       <li>ease-out	</li>
       <li>ease-in-out	</li>
       <!-- <li></li> -->
   </ul>
```

```css
 .box1:hover {
            width: 400px;
            background-color: blue;
        }


        ul {
            width: 800px;
            height: 500px;
            margin: 0 auto;
            border: 1px solid #ccc;
        }

        ul li {
            list-style: none;
            width: 100px;
            height: 50px;
            margin-top: 50px;
            background-color: red;
            transition-property: margin-left;
            transition-duration: 10s;
        }

        ul li:nth-child(1) {
            transition-timing-function: linear;
        }
        ul li:nth-child(2) {
            transition-timing-function: ease;
        }
        ul li:nth-child(3) {
            transition-timing-function: ease-in;
        }
        ul li:nth-child(4) {
            transition-timing-function: ease-out;
        }
        ul li:nth-child(5) {
            transition-timing-function: ease-in-out;
        }
        ul:hover li {
            margin-left: 700px
        }

```

```html
  <!-- 常用属性:
transition-property：告诉系统哪个属性需要执行过渡效果
transition-duration：告诉系统过渡效果持续的时长
transition-delay：告诉系统延迟多少秒之后才开始过渡动画
transition-timing-function：告诉系统过渡动画的运动的速度

1 过渡三要素
1.1必须要有属性发生变化
1.2必须告诉系统哪个属性需要执行过渡效果
1.3必须告诉系统过渡效果持续时长

2.注意点
当多个属性需要同时执行过渡效果时用逗号隔开即可
transition-property: width, background-color;
transition-duration: 5s, 5s; -->


<!-- 值	描述
linear	规定以相同速度开始至结束的过渡效果（等于 cubic-bezier(0,0,1,1)）。
ease	规定慢速开始，然后变快，然后慢速结束的过渡效果（cubic-bezier(0.25,0.1,0.25,1)）。
ease-in	规定以慢速开始的过渡效果（等于 cubic-bezier(0.42,0,1,1)）。
ease-out	规定以慢速结束的过渡效果（等于 cubic-bezier(0,0,0.58,1)）。
ease-in-out	规定以慢速开始和结束的过渡效果（等于 cubic-bezier(0.42,0,0.58,1)）。
cubic-bezier(n,n,n,n) -->
```

### 过渡属性连写

```html
<!-- 过渡模块-连写:

    1.过渡连写格式
    transition: 过渡属性 过渡时长 运动速度 延迟时间;
    
    2.过渡连写注意点
    2.1和分开写一样, 如果想给多个属性添加过渡效果也是用逗号隔开即可
    2.2连写的时可以省略后面的两个参数, 因为只要编写了前面的两个参数就已经满足了过渡的三要素
    2.3如果多个属性运动的速度/延迟的时间/持续时间都一样, 那么可以简写为
    transition:all 0s; -->
```

